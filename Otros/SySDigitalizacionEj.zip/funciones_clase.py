# -*- coding: utf-8 -*-
"""
Created on Tue Sep 10 09:23:33 2019

@author: andre
"""

#%%
import numpy as np
import matplotlib.pyplot as plt
from numpy import matlib as mb
from scipy.spatial.distance import cdist as pdist2

#%% funcion discretizacion coseno
def g_cos(A,Fo,ti,tf,Fs):
    Ts = 1/Fs
#    To = 1/Fo
    Fc = 20*Fs
    Tc = 1/Fc
    if tf > ti:
        vec_t = np.arange(ti,tf,Tc)
        #vec_t = np.linspace(ti,tf,(tf-ti)*Fc)
        xt = A*np.cos(2*np.pi*Fo*vec_t)
    else:
        assert(tf > ti), "tf > ti"
#%% discretizar
    vec_ts = np.arange(ti,tf,Ts)
    wo = 2*np.pi*Fo
    xs = A*np.cos(wo*vec_ts)
    plt.stem(vec_ts,xs,'b',label="x[nTs]")
#%% cuantizar 
    xc = np.array([-1,-0.25,-0.5,-0.75,0,0.25,0.5,0.75,1])
    D = pdist2(xs.reshape(len(xs),1),xc.reshape(len(xc),1))
    ind = np.argmin(D,axis=1)
    xq = np.array([])
    for i in range(len(xs)) :
        print('Iteracion %d/%d' % (i+1,len(xs)))
        xq = np.append(xq,xc[ind[i]])
#%% Graficar
    plt.figure(figsize=(6, 3))
    plt.plot(vec_t,xt,'r',linewidth=4,label="x(t)")
    plt.stem(vec_ts,xs,'b',label='x[nTs]')
    
    for i in range(len(xc)):
        plt.plot(vec_t.reshape(-1,1),mb.repmat(xc[i],len(vec_t),1),'k--')

    plt.plot(vec_ts,xq,'rd', label='Q[x[nTs]]')
    plt.grid()
    plt.legend()
    plt.show()

    return xt, vec_t
#%%
#xt,vec_t = g_cos(A,Fo,ti,tf,Fs)

#%%





